#  File: Spiral.py

#  Description:

#  Student Name: Kyle Hodowany

#  Student UT EID: kwh677

#  Partner Name: Arnav Rai

#  Partner UT EID: akr2673

#  Course Name: CS 313E

#  Unique Number: 52530

#  Date Created: 8/31/2022

#  Date Last Modified: 9/2/2022

import sys

# Input: n is an odd integer between 1 and 100
# Output: returns a 2-D list representing a spiral
#         if n is even add one to n
def CreateSpiral ( n ):
  if (n % 2 == 0):
    n += 1
  Up, Down, Right, Left = (0, -1), (0, 1), (1, 0), (-1, 0)
  turnRight = {Up: Right, Right: Down, Down: Left, Left: Up}
  x, y = n // 2, n // 2
  dx, dy = Up
  spiralMatrix = [[None] * n for _ in range(n)]
  count = 0
  while True:
      count += 1
      spiralMatrix[y][x] = count

      new_dx, new_dy = turnRight[dx,dy]
      new_x, new_y = x + new_dx, y + new_dy

      if (0 <= new_x < n and 0 <= new_y < n and spiralMatrix[new_y][new_x] is None):
          x, y = new_x, new_y
          dx, dy = new_dx, new_dy
      else: 
          x, y = x + dx, y + dy
          if not (0 <= x < n and 0 <= y < n):
              return spiralMatrix

# Input: spiral is a 2-D list and n is an integer
# Output: returns an integer that is the sum of the
#         numbers adjacent to n in the spiral
#         if n is outside the range return 0
def SumAdjacentNumbers (spiral, n):
  pass
def main():
  spiralDimension = int(sys.stdin.readline().strip())
  spiral = CreateSpiral(spiralDimension)
  print(str(spiral))

if __name__ == "__main__":
  main()